# InstaGuard Trigger Map Cyberpunk Game

Created with [Omma](https://omma.build)

## Setup

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```
